add1 = (\ a -> a + 1)
remove1 = (\ a -> a - 1)

execute a = (\ func -> func a)