execute' f a = f a
add1 a = a + 1
remove1 a = a - 1