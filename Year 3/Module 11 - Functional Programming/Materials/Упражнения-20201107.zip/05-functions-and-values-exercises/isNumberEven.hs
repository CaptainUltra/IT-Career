isEven n = 
        if n `mod` 2 == 0
        then True
        else False